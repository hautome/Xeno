import { motion } from 'motion/react';

interface GlassPanelProps {
  children: React.ReactNode;
  className?: string;
}

export function GlassPanel({ children, className = "" }: GlassPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={`
        relative backdrop-blur-xl bg-white/5 border border-white/10
        rounded-2xl p-8 shadow-2xl
        before:absolute before:inset-0 before:rounded-2xl 
        before:bg-gradient-to-br before:from-white/10 before:to-transparent
        before:pointer-events-none
        ${className}
      `}
      style={{
        background: `
          linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%),
          radial-gradient(ellipse at top left, rgba(255,255,255,0.15), transparent 50%),
          radial-gradient(ellipse at bottom right, rgba(255,255,255,0.08), transparent 50%)
        `,
        boxShadow: `
          0 8px 32px rgba(0,0,0,0.3),
          inset 0 1px 1px rgba(255,255,255,0.2),
          inset 0 -1px 1px rgba(0,0,0,0.1)
        `,
      }}
    >
      {children}
    </motion.div>
  );
}