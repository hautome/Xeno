import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

export function ViewCounter() {
  const [views, setViews] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Симуляция загрузки и подсчета просмотров
    const currentViews = localStorage.getItem('siteViews');
    let viewCount = currentViews ? parseInt(currentViews) : Math.floor(Math.random() * 50) + 120;
    
    // Увеличиваем счетчик при каждом посещении
    viewCount += 1;
    localStorage.setItem('siteViews', viewCount.toString());

    // Анимируем появление счетчика
    setTimeout(() => {
      setIsLoading(false);
      let current = 0;
      const increment = viewCount / 30;
      const timer = setInterval(() => {
        current += increment;
        if (current >= viewCount) {
          setViews(viewCount);
          clearInterval(timer);
        } else {
          setViews(Math.floor(current));
        }
      }, 50);
    }, 800);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="fixed top-4 right-4 z-20"
    >
      <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg px-3 py-2">
        <div className="flex items-center space-x-2 text-sm">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-white/60">Просмотры:</span>
          <span className="text-white font-light">
            {isLoading ? '...' : views.toLocaleString()}
          </span>
        </div>
      </div>
    </motion.div>
  );
}