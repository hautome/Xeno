import { motion } from 'motion/react';

export function ShaderBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Фоновое изображение леса */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-50"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1621840090029-08b00c831808?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwZm9yZXN0JTIwbmlnaHQlMjB0cmVlc3xlbnwxfHx8fDE3NTU0MjQyODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`,
          filter: 'grayscale(30%) contrast(1.2) brightness(0.4)'
        }}
      />
      
      {/* Градиентный оверлей */}
      <div 
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(circle at 30% 20%, rgba(0,0,0,0.4) 0%, transparent 60%),
            radial-gradient(circle at 70% 80%, rgba(0,0,0,0.5) 0%, transparent 70%),
            linear-gradient(135deg, rgba(0,0,0,0.7) 0%, rgba(17,17,17,0.8) 50%, rgba(0,0,0,0.7) 100%)
          `
        }}
      />
      
      {/* Тонкие анимированные орбы */}
      <motion.div
        animate={{
          x: [0, 30, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 35,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute top-1/4 left-1/5 w-72 h-72 rounded-full"
        style={{
          background: `radial-gradient(circle, rgba(255,255,255,0.02) 0%, transparent 70%)`,
          filter: 'blur(60px)'
        }}
      />
      
      <motion.div
        animate={{
          x: [0, -40, 0],
          y: [0, 40, 0],
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute bottom-1/4 right-1/5 w-64 h-64 rounded-full"
        style={{
          background: `radial-gradient(circle, rgba(255,255,255,0.015) 0%, transparent 70%)`,
          filter: 'blur(80px)'
        }}
      />

      {/* Тонкая текстура */}
      <div 
        className="absolute inset-0 opacity-[0.02] mix-blend-overlay"
        style={{
          backgroundImage: `
            repeating-linear-gradient(
              45deg,
              transparent,
              transparent 3px,
              rgba(255,255,255,0.008) 3px,
              rgba(255,255,255,0.008) 6px
            )
          `
        }}
      />
    </div>
  );
}